library(tidyr)
library(dplyr)
library(plyr)
library(reshape)
library(ggplot2)
library(stringr)

setwd("/Users/federico/Dropbox/papers/HERO_P1_SLR/analysis")

# Read data

data <- read.delim("./input/summary.txt", header = TRUE, quote = "\"", dec = ".", fill = TRUE, na.strings = c(""," "))
studies <- c(226)

# Barplot function

plot <- function(var, fileName, title, labels, width, height, leftMargin) {

  filePath <- paste("./output/vertical_analysis/", fileName, ".pdf", sep="")
  pdf(filePath, width=width, height=height)
  
  par(mar=c(3, leftMargin, 2, 1))
  par(mfrow=c(1, 1))
  par(las=1)
  var <- as.factor(var)
  levels(var)<-str_replace_all(levels(var), "[_]", " ")
  
  dataToPlot <- table(var)
  dataToPlot <- dataToPlot[order(dataToPlot, decreasing=FALSE)]
  plot <- barplot(dataToPlot, col="#69b3a2", cex.main=1.8, xlim=c(0, 230), cex=1.5, cex.names=1.5, las=1, horiz=TRUE)
  text(x=180, y = plot, label = dataToPlot, cex = 1.5, col = "black")
  
  dev.off()
}  

# Bubble chart function

plotBubbles <- function(var1, var2, name1, name2) {
  
  n1<-str_replace_all(name1, " ", "_")
  n2<-str_replace_all(name2, " ", "_")
  fileName <- paste(n1, "_", n2)
  fileName <- str_replace_all(fileName, " ", "")
  filePath <- paste("./output/orthogonal_analysis/", fileName, ".pdf", sep="")
  pdf(filePath, width=6.5, height=6)
  par(mar=c(5, 5, 5, 5))
  par(mfrow=c(1, 1))
  par(las=1)
  
  currentData <- merge(var1, var2, by="ID", all = T)
  var1Name <- str_replace_all(names(currentData)[2], "[_]", " ")
  var2Name <- str_replace_all(names(currentData)[3], "[_]", " ")
  counts <- count(currentData, c(var1Name, var2Name))
  
  levels(counts[,2])<-str_replace_all(levels(counts[,2]), "[_]", " ")
  levels(counts[,1])<-str_replace_all(levels(counts[,1]), "[_]", " ")
  
  plot <- ggplot(counts, aes(counts[,2], counts[,1], color=freq)) + geom_point(aes(size = freq)) +
    scale_color_gradient2(low="yellow", high="green", name="freq") +
    scale_size_continuous(range=c(0, 30)) + geom_text(aes(label = freq), color="black") +
    theme(legend.position = "none") +
    labs(x=name2, y=name1) #+  ggtitle(paste(name1, " -- ", name2))
  
  print(plot)
  
  dev.off()
}

plotBubbles_wide <- function(var1, var2, name1, name2) {
  
  n1<-str_replace_all(name1, " ", "_")
  n2<-str_replace_all(name2, " ", "_")
  fileName <- paste(n1, "_", n2)
  fileName <- str_replace_all(fileName, " ", "")
  filePath <- paste("./output/orthogonal_analysis/", fileName, ".pdf", sep="")
  pdf(filePath, width=8.5, height=7)
  par(mar=c(5, 5, 5, 5))
  par(mfrow=c(1, 1))
  par(las=1)
  
  currentData <- merge(var1, var2, by="ID", all = T)
  var1Name <- str_replace_all(names(currentData)[2], "[_]", " ")
  var2Name <- str_replace_all(names(currentData)[3], "[_]", " ")
  counts <- count(currentData, c(var1Name, var2Name))
  
  levels(counts[,2])<-str_replace_all(levels(counts[,2]), "[_]", " ")
  levels(counts[,1])<-str_replace_all(levels(counts[,1]), "[_]", " ")
  
  plot <- ggplot(counts, aes(counts[,2], counts[,1], color=freq)) + geom_point(aes(size = freq)) +
    scale_color_gradient2(low="yellow", high="green", name="freq") +
    scale_size_continuous(range=c(0, 30)) + geom_text(aes(label = freq), color="black") +
    theme(legend.position = "none") +
    labs(x=name2, y=name1) #+  ggtitle(paste(name1, " -- ", name2))
  
  print(plot)
  
  dev.off()
}

### Venue type
#labels <- c("Conference", "Workshop", "Journal", "Book_chapter")
#vars0 <- data %>% 
#  gather("var0", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
#  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
#  select(ID, var0) 
#vars0$var0 <- as.factor(vars0$var0)
#plot(vars0$var0, "venue_type", "Venue type", labels, 10, 5, 13)


### Parallel architecture
labels <- c("SISD", "SIMD", "MISD", "MIMD", "SPMD", "Architecture_indep")
  vars1 <- data %>% 
  gather("var1", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
  select(ID, var1) 
vars1$var1 <- as.factor(vars1$var1)
plot(vars1$var1, "parallel_architecture", "Parallel architecture", labels, 10, 5, 13)

### Language abstraction
labels <- c("Modelling_lang",	"High_level_prog_lang")
vars2 <- data %>% 
  gather("var2", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
  select(ID, var2) 
vars2$var2 <- as.factor(vars2$var2)
plot(vars2$var2, "language_abstraction", "Language abstraction", labels, 10, 5, 13)

### Purpose
labels <- c("General_purpose", "Domain_specific")
vars3 <- data %>% 
  gather("var3", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
  select(ID, var3) 
vars3$var3 <- as.factor(vars3$var3)
plot(vars3$var3, "purpose", "Purpose", labels, 10, 5, 13)

### Parallel primitives
labels <- c("Explicit", "Implicit")
vars4 <- data %>% 
  gather("var4", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
  select(ID, var4) 
vars4$var4 <- as.factor(vars4$var4)
plot(vars4$var4, "parallel_primitives", "Parallel primitives", labels, 10, 5, 13)

### Abstract syntax
labels <- c("Metamodel", "Formal_spec", "Context_free_grammar", "Informal_spec")
vars5 <- data %>% 
  gather("var5", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
  select(ID, var5) 
vars5$var5 <- as.factor(vars5$var5)
plot(vars5$var5, "abstract_syntax", "Abstract syntax", labels, 10, 5, 13)

### Concrete syntax
labels <- c("Textual", "Diagrammatic", "Graph", "Tree_based")
vars6 <- data %>% 
  gather("var6", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
  select(ID, var6) 
vars6$var6 <- as.factor(vars6$var6)
plot(vars6$var6, "concrete_syntax", "Concrete syntax", labels, 10, 5, 13)

### Programming paradigm
labels <- c("Imperative", "Declarative", "Object_oriented", "Multi_paradigm", "Actor_based", "Component_based", "Event_driven", "Dynamic")
vars7 <- data %>% 
  gather("var7", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
  select(ID, var7) 
vars7$var7 <- as.factor(vars7$var7)
plot(vars7$var7, "programming_paradigm", "Programming paradigm", labels, 10, 5, 13)

### Communication type
labels <- c("Synchronous", "Asynchronous")
vars8 <- data %>% 
  gather("var8", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
  select(ID, var8) 
vars8$var8 <- as.factor(vars8$var8)
plot(vars8$var8, "communication_type", "Communication type", labels, 10, 5, 13)

### Synchronisation type
labels <- c("Lock", "Barrier", "Rendezvous", "Monitor", "Channel", "Dependency_graph", "Dynamic_interfaces", "Lock_free_data_struct")
vars9 <- data %>% 
  gather("var9", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
  select(ID, var9) 
vars9$var9 <- as.factor(vars9$var9)
plot(vars9$var9, "synchronisation_type", "Synchronisation type", labels, 10, 5, 13)

### Problem decomposition
labels <- c("Task_parallelism",	"Pipeline_parallelism",	"Nested_parallelism",	"Data_parallelism")
vars10 <- data %>% 
  gather("var10", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
  select(ID, var10)
vars10$var10 <- as.factor(vars10$var10)
plot(vars10$var10, "problem_decomposition", "Problem decomposition", labels, 10, 5, 13)

### Communication model
labels <- c("Shared_memory", "Message_passing", "Data_flow", "FIFO_buffer", "Shared_events")
vars11 <- data %>% 
  gather("var11", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
  select(ID, var11) 
vars11$var11 <- as.factor(vars11$var11)
plot(vars11$var11, "communication_model", "Communication model", labels, 10, 5, 13)

### Memory model
labels <- c("Stack_based", "Shared", "Region_based", "Distributed")
vars12 <- data %>% 
  gather("var12", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
  select(ID, var12) 
vars12$var12 <- as.factor(vars12$var12)
plot(vars12$var12, "memory_model", "Memory model", labels, 10, 5, 13)

### Execution mode
labels <- c("Interpreted", "Compiled", "Hybrid")
vars13 <- data %>% 
  gather("var13", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
  select(ID, var13) 
vars13$var13 <- as.factor(vars13$var13)
plot(vars13$var13, "execution_mode", "Execution mode", labels, 10, 5, 13)

### Target language
labels <- c("High_level_lang", "Low_level_lang")
vars14 <- data %>% 
  gather("var14", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
  select(ID, var14) 
vars14$var14 <- as.factor(vars14$var14)
plot(vars14$var14, "target_language", "Target language", labels, 10, 5, 13)

### Target architecture
labels <- c("Multi_CPU", "Many_CPU", "GPU", "GPGPU", "FPGA", "DSA", "Target_indep")
vars15 <- data %>% 
  gather("var15", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
  select(ID, var15) 
vars15$var15 <- as.factor(vars15$var15)
plot(vars15$var15, "target_architecture", "Target architecture", labels, 10, 5, 13)

### Implementation type
labels <- c("Standalone", "Extension")
vars16 <- data %>% 
  gather("var16", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
  select(ID, var16) 
vars16$var16 <- as.factor(vars16$var16)
plot(vars16$var16, "implementation_type", "Implementation type", labels, 10, 5, 13)

### Validation type
labels <- c("Analysis", "Experience", "Example", "Evaluation", "Persuasion", "Blatant_assert")
vars17 <- data %>% 
  gather("var17", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
  select(ID, var17) 
vars17$var17 <- as.factor(vars17$var17)
#plot(vars17$var17, "validation_type", "Validation type", labels, 10, 5, 13)

### Evidence type
labels <- c("Example", "Set_ex", "Empirical_lab", "Industrial_ex", "Set_ind_ex", "Empirical_real")
vars18 <- data %>% 
  gather("var18", "value", labels, na.rm = TRUE, convert = TRUE) %>% 
  #dplyr::filter(grepl("x",value)) %>% dplyr::rename(ID = X) %>% 
  select(ID, var18) 
vars18$var18 <- as.factor(vars18$var18)
#plot(vars18$var18, "evidence_type", "Evidence type", labels, 10, 5, 13)


### Bubble charts
#plotBubbles(vars17, vars18, "Validation type", "Evidence type")

plotBubbles(vars10, vars4, "Problem decomposition", "Parallel primitives")
plotBubbles_wide(vars10, vars7, "Problem decomposition", "Programming paradigm")
plotBubbles(vars10, vars15, "Problem decomposition", "Target architecture")

plotBubbles(vars11, vars12, "Communication model", "Memory model")
plotBubbles(vars11, vars15, "Communication model", "Target architecture")

plotBubbles(vars12, vars4, "Memory model", "Parallel primitives")
plotBubbles(vars12, vars15, "Memory model", "Target architecture")

plotBubbles(vars2, vars13, "Language abstraction", "Execution mode")
plotBubbles(vars2, vars14, "Language abstraction", "Target language")
plotBubbles(vars2, vars15, "Language abstraction", "Target architecture")

plotBubbles(vars7, vars15, "Programming paradigm", "Target architecture")

### just to check multi values in vertical
#plotBubbles(vars10, vars10, "Problem decomposition", "Problem decomposition")
plotBubbles(vars12, vars12, "Memory model", "Memory model")